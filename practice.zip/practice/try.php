<?php
$x=1;
$y=1;
$n="Bigya";
if($x==$y){
    echo $n." is the don ".($x+$y) ;
}
else{
    echo"<b>I am bold</b>";
}
?>