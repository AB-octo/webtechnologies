<table border="1" width="50%">
<?php
$i=1;
while($i<=9){
    if(($i-1)%3==0){
        echo "<tr>";
    }
    echo "<td>".$i."</td>";
    if($i%3==0){
        echo "</tr>";
    }
    $i++;
}
?>
</table>