<?php
$x = 1;
$y = 1;
$z = "my name is ";
$a = 'vivek';
$b = null;
$name = "Anwar";

echo $z.$name.". And my address is Imadol.";
if($x==$y){
    echo "abcd";
}

else{
    echo "efgh";
    echo "ijkl";
}

echo "end";


/* echo $name; */

?>

