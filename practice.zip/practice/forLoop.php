<table border="1" margin="50%">
<?php
for($i=8; $i<73; $i=$i+8){
    if(($i-8)%24==0){
        echo "<tr>";
    }
    echo "<td>".($i)."</td>";
    if(($i%24)==0){
        echo"</tr>";
    }
}
?>
</table>
    <br>
