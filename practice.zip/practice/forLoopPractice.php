<table border="5" height="500px" width="500px">
    <?php
        for($i=1;$i<=81;$i++){
            $result=$i*7;
            if(($result-7)%63==0){
                echo "<tr>";
            }
            echo "<td>".$result."</td>";
            if($result%63==0){
                echo"</tr>";
            }
        }
    ?>
</table>