<!-- numeric array -->
<table border="1">
<?php
$a=["My","name","is","Bigya","Bajra","and","I","am","learning"];
$i=0;
while($i<9){
    if($i%3==0){
        echo"<tr>";
    }
    echo "<td>".$a[$i]."</td>";
    if(($i+1)%3==0){
        echo "</tr>";
    }
    $i++;
}
?>
</table>


<!-- Array can also be written in the following ways:

$a=array(1,"Bigya",33);
$a=[1,"Bigya",33];
$a=array(0=>1,1=>"Bigya",2=>33);
    array(1=>"Bigya",2=>33,0=>1);
$a=[0=>1,1=>"Bigya",2=>33];
$a[0]=1;
$a[1]="Bigya";
$a[2]=33;
$a[]=1;
$a[]="Bigya";
$a[]=33; -->

